// Email Blurb Helper module. Uses its own storage key and does not alter calculator state.
(() => {
const START=[["grant","Grant","✓"],["no-grant","No Grant","✕"],["swdr","SWDR","↻"],["merchpend","MerchPend","◆"]];
const KEY="emailBlurbHelperData_v1",UI_KEY="emailBlurbHelperUI_v1";
let db={actions:[]},act=null,cat=null,scenario=null,manage=null,manageCat=null,level="categories",mode=null,editId=null,view="browse",page="actions",savedScroll=0;
const $=id=>document.getElementById(id),uid=()=>crypto.randomUUID?crypto.randomUUID():Date.now().toString(36)+Math.random().toString(36).slice(2);
const esc=x=>String(x??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const A=()=>db.actions.find(x=>x.id===act),C=()=>A()?.categories.find(x=>x.id===cat),S=()=>C()?.scenarios.find(x=>x.id===scenario);
const MA=()=>db.actions.find(x=>x.id===manage),MC=()=>MA()?.categories.find(x=>x.id===manageCat);
async function save(){await chrome.storage.local.set({[KEY]:db})}
function toast(s){const t=$("emailStorageNote");if(t){t.textContent=s;setTimeout(()=>t.textContent="Saved locally in this Chrome profile · No database or server",1800)}}
// Persist navigation independently from the user's actual blurb data.
let uiScrollTimer=null;
function saveUI(){
 const state={act,cat,scenario,manage,manageCat,level,view,page,
  categorySearch:$("emailCategorySearch").value,scenarioSearch:$("emailScenarioSearch").value,
  scrollTop:document.scrollingElement?.scrollTop||0};
 chrome.storage.local.set({[UI_KEY]:state}).catch(()=>{});
}
function showView(next){
 view=next==="manage"?"manage":"browse";
 $("emailUseView").hidden=view!=="browse";
 $("emailManageView").hidden=view!=="manage";
 $("emailBrowseTab").classList.toggle("active",view==="browse");
 $("emailManageToggle").classList.toggle("active",view==="manage");
 $("emailBrowseTab").setAttribute("aria-selected",String(view==="browse"));
 $("emailManageToggle").setAttribute("aria-selected",String(view==="manage"));
 saveUI();
}
window.addEventListener("scroll",()=>{
 clearTimeout(uiScrollTimer);
 uiScrollTimer=setTimeout(saveUI,180);
},{passive:true});
async function init(){
 const v=await chrome.storage.local.get([KEY,UI_KEY]);db=v[KEY]||{actions:START.map(([id,name,symbol])=>({id,name,symbol,categories:[]}))};
 if(!Array.isArray(db.actions))db={actions:[]};
 for(const [id,name,symbol] of START)if(!db.actions.some(a=>a.id===id))db.actions.push({id,name,symbol,categories:[]});
 for(const a of db.actions){if(!Array.isArray(a.categories))a.categories=[];for(const c of a.categories)if(!Array.isArray(c.scenarios))c.scenarios=[];}
 const u=v[UI_KEY]||{};
 act=u.act||null;cat=u.cat||null;scenario=u.scenario||null;manage=u.manage||null;manageCat=u.manageCat||null;level=u.level||"categories";view=u.view==="manage"?"manage":"browse";page=u.page||"actions";
 $("emailCategorySearch").value=u.categorySearch||"";$("emailScenarioSearch").value=u.scenarioSearch||"";savedScroll=Number(u.scrollTop)||0;
 if(!A()){act=null;cat=null;scenario=null;page="actions"}
 if(!C()){cat=null;scenario=null;page=act?"categories":"actions"}
 if(!S()){scenario=null;if(page==="details")page="scenarios"}
 if(!MA()){manage=db.actions[0]?.id;manageCat=null;level="categories"}
 if(level==="scenarios"&&!MC()){level="categories";manageCat=null}
 await save();showView(view);
 if(view==="browse"){renderUse();if(page==="scenarios"||page==="details")renderCategory();if(page==="details"&&S())renderDetail()}
 else renderManage();
 requestAnimationFrame(()=>{if(savedScroll)document.scrollingElement.scrollTop=savedScroll;});
}
function renderUse(){
 $("emailUseView").hidden=false;$("emailManageView").hidden=true;$("emailBrowseTab").classList.add("active");$("emailManageToggle").classList.remove("active");$("emailBrowseTab").setAttribute("aria-selected","true");$("emailManageToggle").setAttribute("aria-selected","false");
 $("emailActions").innerHTML=db.actions.map(a=>`<button class="email-action ${act===a.id?"active":""}" data-email-act="${esc(a.id)}">${esc(a.symbol||"•")}<br>${esc(a.name)}</button>`).join("");
 document.querySelectorAll("[data-email-act]").forEach(b=>b.onclick=()=>{act=b.dataset.emailAct;cat=null;scenario=null;page="categories";$("emailCategorySearch").value="";$("emailScenarioSearch").value="";saveUI();renderUse()});
 $("emailCategories").hidden=!A();$("emailScenarios").hidden=true;$("emailDetails").hidden=true;$("emailEmpty").hidden=!!A();if(!A())return;
 const q=$("emailCategorySearch").value.toLowerCase(),rows=A().categories.filter(c=>c.name.toLowerCase().includes(q));
 $("emailCategoryList").innerHTML=rows.length?rows.map(c=>`<button class="email-choice" data-email-cat="${esc(c.id)}">${esc(c.name)} <span class="email-arrow">›</span></button>`).join():'<div class="email-empty">No categories yet. Use Manage data to add categories.</div>';
 document.querySelectorAll("[data-email-cat]").forEach(b=>b.onclick=()=>{cat=b.dataset.emailCat;scenario=null;page="scenarios";saveUI();renderCategory()});
}
function renderUseListsOnly(){ if(act){ const oldCat=cat,oldScenario=scenario; const a=A(); if(a){ $("emailCategoryList").innerHTML=a.categories.map(c=>`<button class="email-choice" data-email-cat="${esc(c.id)}">${esc(c.name)} <span class="email-arrow">›</span></button>`).join(""); } cat=oldCat;scenario=oldScenario; } }
function renderCategory(){
 const c=C();if(!c)return;$("emailCategories").hidden=true;$("emailScenarios").hidden=false;$("emailDetails").hidden=true;$("emailScenarioHeading").textContent="SCENARIOS · "+c.name;
 const q=$("emailScenarioSearch").value.toLowerCase(),rows=c.scenarios.filter(s=>[s.name,s.reasonCode,s.blurbName].join(" ").toLowerCase().includes(q));
 $("emailScenarioList").innerHTML=rows.length?rows.map(s=>`<button class="email-choice" data-email-scen="${esc(s.id)}">${esc(s.name)} <span class="email-arrow">›</span></button>`).join():'<div class="email-empty">No scenarios yet. Use Manage data to add scenarios.</div>';
 document.querySelectorAll("[data-email-scen]").forEach(b=>b.onclick=()=>{scenario=b.dataset.emailScen;page="details";saveUI();renderDetail()});
}
function renderDetail(){
 const c=C(),s=S();if(!s)return;$("emailScenarios").hidden=true;$("emailDetails").hidden=false;$("emailDetailsHeading").textContent=c.name+" › "+s.name;
 $("emailReason").textContent=s.reasonCode||"—";$("emailBlurb").textContent=s.blurbName||"—";$("emailAnnotation").textContent=s.annotations||"—";
}
$("emailCategorySearch").oninput=()=>{saveUI();renderUse()};$("emailScenarioSearch").oninput=()=>{saveUI();cat&&renderCategory()};
$("emailChangeAction").onclick=()=>{act=null;cat=null;scenario=null;page="actions";saveUI();renderUse()};
$("emailBackCategories").onclick=()=>{$("emailScenarios").hidden=true;$("emailDetails").hidden=true;$("emailCategories").hidden=false;cat=null;scenario=null;page="categories";saveUI()};
$("emailBackScenarios").onclick=()=>{$("emailDetails").hidden=true;$("emailScenarios").hidden=false;scenario=null;page="scenarios";saveUI()};
$("emailCopy").onclick=async()=>{const s=S();if(!s?.annotations){toast("No annotations to copy");return}try{await navigator.clipboard.writeText(s.annotations);toast("Annotations copied")}catch{toast("Clipboard unavailable")}};
function renderManage(){
 if(!manage||!db.actions.some(a=>a.id===manage))manage=db.actions[0]?.id;
 $("emailManageAction").innerHTML=db.actions.map(a=>`<option value="${esc(a.id)}">${esc(a.name)}</option>`).join("");$("emailManageAction").value=manage||"";
 const a=MA();if(level==="scenarios"&&!MC())level="categories";
 if(level==="categories"){
  $("emailManageHeading").textContent="Categories";$("emailAdd").textContent="＋ Add Category";
  $("emailManageList").innerHTML=a?.categories.length?a.categories.map(c=>`<div class="email-manage-item"><button class="email-open-cat" data-email-open="${esc(c.id)}">${esc(c.name)} <span class="email-arrow">›</span></button><button class="email-row-btn" data-email-edit-cat="${esc(c.id)}">Edit</button><button class="email-row-btn delete" data-email-del-cat="${esc(c.id)}">Delete</button></div>`).join():'<div class="email-empty">No categories added for this action.</div>';
  document.querySelectorAll("[data-email-open]").forEach(b=>b.onclick=()=>{manageCat=b.dataset.emailOpen;level="scenarios";saveUI();renderManage()});
  document.querySelectorAll("[data-email-edit-cat]").forEach(b=>b.onclick=()=>openEditor("category",b.dataset.emailEditCat));
  document.querySelectorAll("[data-email-del-cat]").forEach(b=>b.onclick=()=>deleteCategory(b.dataset.emailDelCat));
 }else{
  const c=MC();$("emailManageHeading").innerHTML=`<button id="emailManageBack" class="email-link">← Categories</button> · Scenarios: ${esc(c.name)}`;$("emailAdd").textContent="＋ Add Scenario";
  $("emailManageList").innerHTML=c.scenarios.length?c.scenarios.map(s=>`<div class="email-manage-item"><span class="email-item-name">${esc(s.name)}</span><button class="email-row-btn" data-email-edit-scen="${esc(s.id)}">Edit</button><button class="email-row-btn delete" data-email-del-scen="${esc(s.id)}">Delete</button></div>`).join():'<div class="email-empty">No scenarios in this category.</div>';
  $("emailManageBack").onclick=()=>{level="categories";manageCat=null;saveUI();renderManage()};
  document.querySelectorAll("[data-email-edit-scen]").forEach(b=>b.onclick=()=>openEditor("scenario",b.dataset.emailEditScen));
  document.querySelectorAll("[data-email-del-scen]").forEach(b=>b.onclick=()=>deleteScenario(b.dataset.emailDelScen));
 }
}
$("emailBrowseTab").onclick=()=>{showView("browse");renderUse();if(page==="scenarios"||page==="details")renderCategory();if(page==="details"&&S())renderDetail()};
$("emailManageToggle").onclick=()=>{showView("manage");renderManage()};
$("emailManageAction").onchange=e=>{manage=e.target.value;manageCat=null;level="categories";closeEditor();saveUI();renderManage()};
$("emailAdd").onclick=()=>openEditor(level==="categories"?"category":"scenario");
function openEditor(which,idv=null){
 mode=which;editId=idv;$("emailEditor").hidden=false;saveUI();
 const obj=which==="category"?MA().categories.find(x=>x.id===idv):MC()?.scenarios.find(x=>x.id===idv);
 $("emailEditorTitle").textContent=(idv?"Edit ":"Add ")+(which==="category"?"Category":"Scenario");
 $("emailFields").innerHTML=which==="category"
 ?`<label>Category name</label><input id="emailFName" required maxlength="80" value="${esc(obj?.name||"")}" placeholder="e.g. NOCOT">`
 :`<label>Scenario name</label><input id="emailFName" required maxlength="120" value="${esc(obj?.name||"")}" placeholder="Scenario name"><label>Reason code</label><input id="emailFReason" maxlength="140" value="${esc(obj?.reasonCode||"")}" placeholder="Reason code"><label>Blurb name</label><input id="emailFBlurb" maxlength="180" value="${esc(obj?.blurbName||"")}" placeholder="Blurb name"><label>Annotations</label><textarea id="emailFAnnotation" placeholder="Paste or type annotation / email text">${esc(obj?.annotations||"")}</textarea>`;
 $("emailFName").focus();
}
function closeEditor(){$("emailEditor").hidden=true;mode=null;editId=null}
$("emailCloseEditor").onclick=$("emailCancel").onclick=closeEditor;
$("emailForm").onsubmit=async e=>{
 e.preventDefault();const name=$("emailFName").value.trim();if(!name)return;
 if(mode==="category"){const a=MA();let o=editId?a.categories.find(x=>x.id===editId):null;if(!o){if(a.categories.length>=5){toast("Maximum 5 categories per action");return}o={id:uid(),scenarios:[]};a.categories.push(o)}o.name=name}
 else{const c=MC();if(!c)return;let o=editId?c.scenarios.find(x=>x.id===editId):null;if(!o){o={id:uid()};c.scenarios.push(o)}o.name=name;o.reasonCode=$("emailFReason").value.trim();o.blurbName=$("emailFBlurb").value.trim();o.annotations=$("emailFAnnotation").value}
 await save();closeEditor();saveUI();renderManage();renderUseListsOnly();toast("Saved");
};
async function deleteCategory(cid){const a=MA(),c=a.categories.find(x=>x.id===cid);if(!c||!confirm(`Delete "${c.name}" and all its scenarios?`))return;a.categories=a.categories.filter(x=>x.id!==cid);if(manageCat===cid)manageCat=null;await save();if(cat===cid){cat=null;scenario=null;page="categories"}saveUI();renderManage();renderUse();toast("Category deleted")}
async function deleteScenario(sid){const c=MC(),s=c.scenarios.find(x=>x.id===sid);if(!s||!confirm(`Delete "${s.name}"?`))return;c.scenarios=c.scenarios.filter(x=>x.id!==sid);await save();if(scenario===sid){scenario=null;page="scenarios"}saveUI();renderManage();renderUse();toast("Scenario deleted")}
$("emailExport").onclick=()=>{const u=URL.createObjectURL(new Blob([JSON.stringify(db,null,2)],{type:"application/json"}));const a=document.createElement("a");a.href=u;a.download="email-blurb-helper-backup.json";a.click();URL.revokeObjectURL(u);toast("Backup exported")};
$("emailImport").onchange=async e=>{const f=e.target.files[0];if(!f)return;try{const x=JSON.parse(await f.text());if(!x||!Array.isArray(x.actions))throw Error("Invalid backup");for(const a of x.actions){if(typeof a.name!=="string"||!Array.isArray(a.categories))throw Error("Invalid action data");for(const c of a.categories){if(typeof c.name!=="string"||!Array.isArray(c.scenarios))throw Error("Invalid category data");for(const s of c.scenarios)if(typeof s.name!=="string")throw Error("Invalid scenario data")}}if(!confirm("Import will replace your Email Blurb data. Continue?"))return;db=x;for(const [id,name,symbol] of START)if(!db.actions.some(a=>a.id===id))db.actions.push({id,name,symbol,categories:[]});manage=null;manageCat=null;level="categories";act=cat=scenario=null;view="browse";page="actions";await save();saveUI();renderManage();renderUse();toast("Backup imported")}catch(err){toast("Import failed: "+err.message)}finally{e.target.value=""}};
init();
})();