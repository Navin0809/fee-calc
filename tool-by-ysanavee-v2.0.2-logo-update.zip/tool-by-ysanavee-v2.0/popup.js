const $=id=>document.getElementById(id);
const months=["January","February","March","April","May","June","July","August","September","October","November","December"];
const date=(y,m,d)=>new Date(y,m,d,12), fmt=d=>`${d.getDate()} ${months[d.getMonth()]} ${d.getFullYear()}`;
const same=(a,b)=>!!a&&!!b&&a.getFullYear()===b.getFullYear()&&a.getMonth()===b.getMonth()&&a.getDate()===b.getDate();
const STORAGE_KEY="toolByYsanaveeState_v2";
const today=new Date();
let selected=null, vy=today.getFullYear(), vm=today.getMonth(), days=null, chargebackOn=false;
function status(id,s){$(id).textContent=s}
function saveState(){
 const state={
  selectedDate:selected?fmt(selected):null, days, chargebackOn,
  fields:["productValue","amazonFees","deliveryCharges","asinQuantity","chargebackBase","chargebackTax","finalQuantity"].reduce((a,id)=>(a[id]=$(id).value,a),{})
 };
 try{localStorage.setItem(STORAGE_KEY,JSON.stringify(state))}catch{}
}
function restoreState(){
 try{
  let saved=JSON.parse(localStorage.getItem(STORAGE_KEY)||"null");
  if(!saved){
   // Migrate fee values from v1.5 without bringing forward its old hard-coded date defaults.
   const old=JSON.parse(localStorage.getItem("toolByYsanaveeState")||"null");
   if(old){
    saved={fields:old.fields||{},chargebackOn:!!old.chargebackOn,selectedDate:null,days:null};
    const oldDate=old.selectedDate;
    if(oldDate && !(oldDate==="12 September 2026" && Number(old.days)===50)){
     saved.selectedDate=oldDate;
     if([7,45,50,52].includes(Number(old.days)))saved.days=Number(old.days);
    }
   }
  }
  if(!saved)return;
  if(typeof saved.selectedDate==="string"){
   const m=saved.selectedDate.match(/^(\d{1,2}) ([A-Za-z]+) (\d{4})$/);
   if(m){const mi=months.indexOf(m[2]);if(mi>=0){selected=date(+m[3],mi,+m[1]);vy=selected.getFullYear();vm=selected.getMonth()}}
  }
  if([7,45,50,52].includes(Number(saved.days)))days=Number(saved.days);
  chargebackOn=!!saved.chargebackOn;
  if(saved.fields&&typeof saved.fields==="object"){
   ["productValue","amazonFees","deliveryCharges","asinQuantity","chargebackBase","chargebackTax","finalQuantity"].forEach(id=>{
    if(typeof saved.fields[id]==="string")$(id).value=saved.fields[id];
   });
  }
 }catch{}
}
function updateDate(){
 $("dateDisplay").value=selected?fmt(selected):"";
 if(selected&&days!==null){
  const result=date(selected.getFullYear(),selected.getMonth(),selected.getDate()+days);
  $("finalDate").textContent=fmt(result);
  $("dateNote").textContent=`${days} days added to ${fmt(selected)}`;
 }else{
  $("finalDate").textContent="—";
  $("dateNote").textContent=!selected&&!days?"Choose a start date and number of days":!selected?"Choose a start date":"Choose number of days";
 }
 $("copyStartDate").disabled=!selected;
 $("copyDate").disabled=!(selected&&days!==null);
 saveState();
}
function closeCal(){$("calendarPopover").hidden=true;$("dateDisplay").setAttribute("aria-expanded","false")}
function renderCal(){
 $("monthTitle").textContent=`${months[vm]} ${vy}`;
 const first=date(vy,vm,1),off=first.getDay(),count=date(vy,vm+1,0).getDate(),prev=date(vy,vm,0).getDate(),today=new Date(),grid=$("calendarGrid");grid.replaceChildren();
 for(let i=0;i<42;i++){
  let y=vy,m=vm,d,out=false;
  if(i<off){d=prev-off+i+1;m=vm-1;out=true}
  else if(i>=off+count){d=i-off-count+1;m=vm+1;out=true}
  else d=i-off+1;
  let dt=date(y,m,d),b=document.createElement("button");b.type="button";b.textContent=d;
  if(out)b.classList.add("outside");
  if(same(dt,selected))b.classList.add("selected");
  if(same(dt,today))b.classList.add("today");
  b.setAttribute("aria-label",fmt(dt));
  b.onclick=()=>{selected=dt;vy=dt.getFullYear();vm=dt.getMonth();updateDate();renderCal();closeCal();status("dateStatus","")};
  grid.append(b);
 }
}
function openCal(){$("calendarPopover").hidden=false;$("dateDisplay").setAttribute("aria-expanded","true");renderCal()}
$("calendarToggle").onclick=()=>$("calendarPopover").hidden?openCal():closeCal();
$("dateDisplay").onclick=openCal;
$("prevMonth").onclick=()=>{if(--vm<0){vm=11;vy--}renderCal()};
$("nextMonth").onclick=()=>{if(++vm>11){vm=0;vy++}renderCal()};
$("todayButton").onclick=()=>{let t=new Date();selected=date(t.getFullYear(),t.getMonth(),t.getDate());vy=selected.getFullYear();vm=selected.getMonth();updateDate();renderCal();closeCal()};
$("closeCalendar").onclick=closeCal;
document.querySelectorAll(".day-option").forEach(b=>b.onclick=()=>{
 days=+b.dataset.days;
 document.querySelectorAll(".day-option").forEach(x=>x.classList.toggle("active",x===b));
 updateDate();status("dateStatus","");
});
async function copyDateText(value,label){
 try{await navigator.clipboard.writeText(value);status("dateStatus",`${label} copied.`)}
 catch{status("dateStatus","Copy unavailable; please copy manually.")}
}
$("copyStartDate").onclick=()=>{if(selected)copyDateText($("dateDisplay").value,"Selected date")};
$("copyDate").onclick=()=>{if(selected&&days!==null)copyDateText($("finalDate").textContent,"Final date")};
$("clearDate").onclick=()=>{
 selected=null;days=null;vy=today.getFullYear();vm=today.getMonth();
 document.querySelectorAll(".day-option").forEach(b=>b.classList.remove("active"));
 closeCal();updateDate();status("dateStatus","");
};
function amount(id,label,required=false){
 let raw=$(id).value.trim();if(!raw&&!required)return 0;if(!raw)throw Error(`Enter ${label}.`);
 let n=Number(raw);if(!Number.isFinite(n)||n<0)throw Error(`${label} must be a valid non-negative amount.`);return n;
}
function calc(){
 $("feeError").textContent="";
 try{
  let product=amount("productValue","Total Product Value",true),fees=amount("amazonFees","Amazon Fees"),delivery=amount("deliveryCharges","Delivery by Amazon Charges"),asinQty=amount("asinQuantity","ASIN Quantity",true),base=chargebackOn?amount("chargebackBase","Chargeback Base Amount"):0,tax=chargebackOn?amount("chargebackTax","Chargeback Tax"):0,finalQty=amount("finalQuantity","Quantity",true);
  if(product<=0)throw Error("Total Product Value must be greater than $0.");
  if(!Number.isInteger(asinQty)||asinQty<1)throw Error("ASIN Quantity must be a whole number greater than zero.");
  if(!Number.isInteger(finalQty)||finalQty<1)throw Error("Quantity must be a whole number greater than zero.");

  // Follow the user's calculator sequence:
  // product - fees; subtract net delivery allocated across ASIN quantity;
  // multiply by 100; divide by product; then divide by final quantity.
  const chargeback = base + tax;
  const netDelivery = delivery - chargeback;
  const deliveryPerAsin = netDelivery / asinQty;
  const remainingValue = product - fees - deliveryPerAsin;
  const pct = ((remainingValue * 100) / product) / finalQty;

  // Keep exactly two decimal places by truncating, not rounding.
  // A tiny epsilon protects mathematically exact decimal boundaries from
  // binary floating-point representation noise.
  const adjustedPct = pct + Math.sign(pct) * 1e-10;
  const result = (Math.trunc(adjustedPct * 100) / 100).toFixed(2);

  $("finalPercentage").textContent=result+"%";$("feeNote").textContent="After Amazon fees and net delivery charges";
  return {pct, result};
 }catch(e){$("finalPercentage").textContent="—";$("feeNote").textContent="Check the values entered below";$("feeError").textContent=e.message;return null}
}
["productValue","amazonFees","deliveryCharges","asinQuantity","chargebackBase","chargebackTax","finalQuantity"].forEach(id=>$(id).addEventListener("input",()=>{saveState();calc()}));
function toggleChargeback(on){
 chargebackOn=on;$("chargebackFields").hidden=!on;
 $("chargebackYes").classList.toggle("active",on);$("chargebackNo").classList.toggle("active",!on);
 $("chargebackYes").setAttribute("aria-pressed",String(on));$("chargebackNo").setAttribute("aria-pressed",String(!on));
 if(!on){$("chargebackBase").value="";$("chargebackTax").value=""}
 saveState();calc();
}
$("chargebackNo").onclick=()=>toggleChargeback(false);
$("chargebackYes").onclick=()=>toggleChargeback(true);
$("copyFee").onclick=async()=>{let r=calc();if(!r)return;try{await navigator.clipboard.writeText(r.result);status("feeStatus","Result copied.")}catch{status("feeStatus","Copy unavailable.")}};
$("clearFee").onclick=()=>{
 ["productValue","amazonFees","deliveryCharges","chargebackBase","chargebackTax"].forEach(id=>$(id).value="");
  $("asinQuantity").value="1";$("finalQuantity").value="1";
 toggleChargeback(false);$("finalPercentage").textContent="—";$("feeNote").textContent="Enter values to calculate";
 $("feeError").textContent="";saveState();status("feeStatus","");
};
document.querySelectorAll(".tab").forEach(t=>t.onclick=()=>{
 let d=t.dataset.tab==="date", f=t.dataset.tab==="fee";
 document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x===t));
 $("datePanel").hidden=!d;$("feePanel").hidden=!f;$("emailPanel").hidden=t.dataset.tab!=="email";closeCal();
});
function theme(t){
 document.body.classList.toggle("dark",t==="dark");
 $("themeToggle").setAttribute("aria-label",t==="dark"?"Switch to light mode":"Switch to dark mode");
 try{localStorage.setItem("utilityCalculatorTheme",t)}catch{}
}
let savedTheme="light";try{savedTheme=localStorage.getItem("utilityCalculatorTheme")||"light"}catch{}
theme(savedTheme);$("themeToggle").onclick=()=>theme(document.body.classList.contains("dark")?"light":"dark");
restoreState();
document.querySelectorAll(".day-option").forEach(b=>b.classList.toggle("active",Number(b.dataset.days)===days));
$("chargebackFields").hidden=!chargebackOn;
$("chargebackYes").classList.toggle("active",chargebackOn);$("chargebackNo").classList.toggle("active",!chargebackOn);
$("chargebackYes").setAttribute("aria-pressed",String(chargebackOn));$("chargebackNo").setAttribute("aria-pressed",String(!chargebackOn));
updateDate();calc();
