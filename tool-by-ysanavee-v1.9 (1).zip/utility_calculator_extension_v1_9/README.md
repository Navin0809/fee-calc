# Utility Calculator v1.1

Chrome Manifest V3 extension.

## Install
1. Extract this ZIP.
2. Open `chrome://extensions`.
3. Enable Developer mode.
4. Click Load unpacked and select this folder.
5. Pin Utility Calculator.

## Updated Amazon fee calculation
Net Delivery by Amazon Charges = Delivery by Amazon Charges - Chargeback Base Amount - Chargeback Tax.

Final Product Value Percentage =
((Total Product Value - Amazon Fees - Net Delivery by Amazon Charges) / Total Product Value) * 100.

All amounts are USD. Blank Amazon fee, delivery, or chargeback components are treated as zero; Total Product Value must be greater than zero.


Version 1.2.0: compact popup, N branding, renamed tabs (Date Utility and Fee Analyzer), and removed the fee breakdown rows while retaining the calculation.


Version 1.3.0: updated ysanavee calc branding and investigation logo. Added separate copy buttons beside the selected start date and calculated final date.


Version 1.4.0: replaced icon-only date copy controls with labelled Copy buttons and simplified popup branding to a single name: Tool by ysanavee.


Version 1.5.0: automatically persists Date Utility and Fee Analyzer inputs in extension local storage. Values are restored when the popup is reopened and remain until the corresponding Clear button is used.


Version 1.6.0: fresh installs now start with a blank date and no day preset selected. The final date stays blank until both a start date and a day preset are chosen. Date Utility Clear resets to this blank state. Autosave continues to retain deliberate user selections and Fee Analyzer values until cleared.


Version 1.7.0: Fee Analyzer Copy Result now copies only the numeric percentage value to two decimal places (for example, 45.03), without a percent sign or spaces.


Version 1.8.0: Fee Analyzer now follows the manual calculation sequence (remaining value × 100 ÷ product value), truncates the final percentage to two decimal places without rounding up, and uses the identical formatted value for display and copying.


Version 1.9.0: Added ASIN Quantity (default 1) to divide net delivery charges per ASIN, plus a final Quantity field (default 1) to divide the calculated percentage. Both fields autosave, validate as positive whole numbers, and reset to 1 when Fee Analyzer is cleared.
